wavFeatExt <-
function(data, type){
  # This function performes wavelet transform to obtain 
  # detail or scaling coefficient of input data
  # Input:
  # data: either a matrix, list of matrices 
  #    (rows=obs, cols=vars),or output from simCNA function
  # type: type of the coefficient you want to extract. 
  #    "detail" for "detail coefficient" and "scaling" for "scaling coefficient"
  
  if(is.list(data)==TRUE){
    n.sim <- length(data)
    n.sampl <- length(data[[1]][,1])
  }else{
    n.sim <- 1
    n.sampl <- nrow(data)
    data <- list(data)
  }
  
  coef = list()
  for (i in 1:n.sim) {
    if(type=="detail"){
      temp.coef = nhwt(data[[i]], type="detail")
    }else if(type=="scaling"){
      temp.coef = nhwt(data[[i]], type="scaling")
    }else{
      print("choose either 'detail' or 'scaling' ")
    }
    
    temp.sca.coef = nhwt(data[[i]], type="scaling")
    
    if(i==1){
      coef = list(temp.coef)
      sca.coef = list(temp.sca.coef)
    }else{
      coef = append(coef, list(temp.coef))
      sca.coef = append(sca.coef, list(temp.sca.coef))
    }
  }
  return(coef)
}
