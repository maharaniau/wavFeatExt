classif.wavFeatExt <-
function(data, y, det, sca, method, k, ite = length(data)){
  # This function performes 6 types of classification methods
  # Lasso, Elnet, Random Forest (RF), Neural Network (NN), PLS, KNN
  # Input:
  # data: either list of matrices (rows=obs, cols=vars),
  #     or output from simCNA function
  # y: response variable 
  # det: detail coefficient of the data
  # sca: scaling coefficient of the data
  # method: Type of the classification method you want to use. 
  #    'lasso' for Lasso, 'elnet' for elastic net, 
  #    'RF' for Random Forest, 'NN' for Neural Network, 
  #    'PLS' for penalized least squares, 'KNN' for k-nearest neighbour.
  # k: number of folds - default is 5
  # ite: number of iteration, default is equal to the length of data
  
  n.data <- length(data[[1]][,1])
  l.data <- length(data[[1]][1,])
  
  fold_size =length(y)/k
  indices = rep(1:k,rep(fold_size,k))
  id = matrix(0,n.data,l.data)
  id = apply(id, 2,function(p) sample(indices, replace = FALSE))
  n.sim <- length(data)
  
  all.mce = all.mauc = vector()
  
  
  
  for (i in 1:ite) {
    if(length(data)==1){i=1}
    mce = mauc =  vector()
    for (s in 1:(2*(floor(log2(l.data)))-1)) {
      if(s==(2*(floor(log2(l.data)))-1)){
        if(n.sim==1){
          x = as.matrix(unname(data[[1]]))
        }else{
          x = data[[i]]
        }
      }
      if(s>(floor(log2(l.data))-1) & s< (2*(floor(log2(l.data)))-1)){
        if(n.sim==1){
          x = as.matrix(sca[[1]][[s-(floor(log2(l.data))-1)]])
        }else{
          x = as.matrix(sca[[i]][[s-(floor(log2(l.data))-1)]])
        }
      }
      if(s<=(floor(log2(l.data))-1)){
        if(n.sim==1){
          x = as.matrix(det[[1]][[s]])
        }else{
          x = as.matrix(det[[i]][[s]])
        }
      }
      ce = auc = vector()
      
      for(f in 1:k){
        x.train = x[-(which(id[,i]==f)),]
        y.train = y[-(which(id[,i]==f))]
        data.train = data.frame(ytrain = as.factor(y.train), x.train)
        
        x.test = x[(which(id[,i]==f)),]
        y.test = y[(which(id[,i]==f))]
        
        if(method == "lasso"){
          lasso.fit = cv.glmnet(x.train, y.train, family = "binomial", type.measure = "class", alpha=1)
          predicted = predict(lasso.fit, s=lasso.fit$lambda.1se, newx = x.test, type = "response")
          ce = cbind(ce, as.numeric(assess.glmnet(lasso.fit, newx=x.test, newy=y.test, family="binomial")$class))
        }
        
        if(method == "elnet"){
          elnet.fit = cv.glmnet(x.train, y.train, family = "binomial", type.measure = "class", alpha=0.5)
          predicted = predict(elnet.fit, s=elnet.fit$lambda.1se, newx = x.test, type = "response")
          ce = cbind(ce, as.numeric(assess.glmnet(elnet.fit, newx=x.test, newy=y.test, family="binomial")$class))
        }
        
        if(method == "RF"){
          RF = randomForest(x = x.train, y = as.factor(y.train))
          RF.predicted = as.vector(predict(RF, newdata = x.test, predict.all = TRUE))
          RF.predicted.v = as.vector(predict(RF, newdata = x.test, predict.all = TRUE, type="vote"))
          predicted = RF.predicted.v$aggregate[,2]
          ce = cbind(ce, (sum(RF.predicted$aggregate!=y.test)/length(y.test)))
        }
        
        if(method == "NN"){
          NN = neuralnet(ytrain ~., data.train)
          NN.predicted = as.vector(compute(NN, x.test))
          predicted = NN.predicted$net.result[,2]
          ce = cbind(ce, (sum(round(NN.predicted$net.result[,2], digits = 0)!=y.test)/length(y.test)))
        }
        
        if(method == "KNN"){
          KNN = knn3(x.train, as.factor(y.train), k=3)
          KNN.predicted = predict(KNN, x.test, type="class")
          KNN.predicted.prob = predict(KNN, x.test, type="prob")
          predicted = KNN.predicted.prob[,2]
          ce = cbind(ce, (sum(KNN.predicted!=y.test)/length(y.test)))
        }
        
        if(method == "PLS"){
          PLS = plsda(x.train, as.factor(y.train), type="prob")
          PLS.predicted = predict(PLS, x.test, type="class")
          PLS.predicted.prob = matrix(predict(PLS, x.test, type="prob"),nrow=length(y.test),2)
          predicted = PLS.predicted.prob[,2]
          ce = cbind(ce, (sum(PLS.predicted!=y.test)/length(y.test)))
        }
        
        roc = roc(y.test, as.numeric(predicted))
        auc = cbind(auc, auc(roc))
      }
      
      mce = cbind(mce, mean(ce))
      mauc = cbind(mauc, mean(auc))
    }
    all.mce = rbind(all.mce, mce)
    all.mauc = rbind(all.mauc, mauc)
  }
  results = list(CE = as.matrix(all.mce), AUC = as.matrix(all.mauc), method = method)
  return(results)
}
