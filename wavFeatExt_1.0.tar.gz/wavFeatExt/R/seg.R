seg <-
function(test.noise, denoise){
# Perform segmentation for each observation
# in a data matrix
# Modification of function gen.sampl() by Maharani Ummi (maharaniahsani@gmail.com)
# Input: 
# test.noise: data for one patient/observation
# denoise: segmentation method
# A.Gusnanto@leeds.ac.uk
  n = ncol(test.noise)
  nrow.x <- nrow(test.noise)
  #segmentation
  test.seg = matrix(0,nrow.x,n)
    if(denoise=="CBS"){
    for (i in 1:nrow.x) {
      test.seg[i,] = CBS(test.noise[i,], chr=rep(1,n))
    }
  }
  
  return(test.seg)
}
