plot.nhwt <-
function (obj.nhwt, coef = "detail", type = "global", scale = "all") 
{
    obj.nhwt = matrix(unlist(obj.nhwt), ncol = length(obj.nhwt[[1]]), byrow=TRUE)
    n = ncol(obj.nhwt)
    n.up = ceiling(log2(n))
    n.extend = 2^n.up
    n.res = n.extend - n
    
    if(scale=="all"){
      if (coef == "detail") {
          plot(1, type = "n", xlab = "", ylab = "Scale", xlim = c(0, 
              n), ylim = c(0, (log2(n.extend) - 1) * 2), yaxt = "n", 
              main = "Haar NHWT (Detail) Coefficients")
      }
      if (coef == "scaling") {
          plot(1, type = "n", xlab = "", ylab = "Scale", xlim = c(0, 
              n), ylim = c(0, (log2(n.extend) - 1) * 2), yaxt = "n", 
              main = "Haar NHWT (Scaling) Coefficients")
      }
      
      if(type=="global"){
        axis(2, at = seq(1, 2 * (log2(n.extend) - 1), 2), labels = seq(1, 
            log2(n), 1))
        for (level in 1:(log2(n.extend) - 1)) {
            for (i in 1:n) {
                lines(c(i, i), c(level * 2 - 1, (obj.nhwt[level, 
                    i]/max(abs(obj.nhwt)) + level * 2 - 1)))
            }
        }
      }
      if(type=="by.level"){
        axis(2, at = seq(1, 2 * (log2(n.extend) - 1), 2), labels = seq(1, 
                                                                       log2(n), 1))
        for (level in 1:(log2(n.extend) - 1)) {
          for (i in 1:n) {
            lines(c(i, i), c(level * 2 - 1, (obj.nhwt[level, 
                i]/max(abs(obj.nhwt[level,])) + level * 2 - 1)))
          }
        }
      }
    }

    if(scale>0 & scale<=nrow(obj.nhwt)){
      if (coef == "detail") {
        plot(1, type = "n", xlab = "", ylab = "Scale", xlim = c(0, 
                                                                n), ylim = c(0, 2), yaxt = "n", 
             main = "Haar NHWT (Detail) Coefficients")
      }
      if (coef == "scaling") {
        plot(1, type = "n", xlab = "", ylab = "Scale", xlim = c(0, 
                                                                n), ylim = c(0, 2), yaxt = "n", 
             main = "Haar NHWT (Scaling) Coefficients")
      }
      axis(2, at = 1, labels = scale)
      for (i in 1:n) {
        lines(c(i, i), c(1 * 2 - 1, (obj.nhwt[scale, 
                                                  i]/max(abs(obj.nhwt[scale,])) + 1 * 2 - 1)))
      }
    }
   
}
