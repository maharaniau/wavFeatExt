CBS <-
function(obj, chr = rep(1, length(obj))){
# Function for CBS Segmentation
# Maharani Ummi maharaniahsani@gmail.com

  CNA.obj = CNA(obj, chrom = chr, maploc = 1:length(obj), data.type = "binary")
  CBS = segment(CNA.obj)
  num.seg = length(CBS$segRows$startRow)
  CBS.seg = vector()
  for(k in 1:num.seg){
    CBS.seg[CBS$segRows$startRow[k]:CBS$segRows$endRow[k]] = CBS$output$seg.mean[k]
  }
  return(CBS.seg)
}
