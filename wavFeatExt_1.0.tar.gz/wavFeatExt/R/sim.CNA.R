sim.CNA <-
function(n.obs=100, p=1024, n.sim=1, effect.diff=1, 
n.block=32, true.rho=0.9, block.cor=0.4, block.diff="A", 
true.mu = NULL){

# function to generate CNA data by Arief Gusnanto (a.gusnanto@leeds.ac.uk)
# Input:
# n.obs : number of observations in a simulated data, must be even 
#         so that half to group 1 and the other half to group 2
if(n.obs%%2!=0) stop("Number of observations in a simulated data must be even")
# p: number of predictors/genomic locations. At the moment, must be power of two
#    because of the use of wavelet in current analysis
# n.sim : the number of datasets to generate (each of them is of size n.obs times p)
# effect.diff: The magnitude of differences betwen the two groups
# n.block: number of blocks in the simulated data. It must have
#          divisor 2 (for block.diff type "A") and divisor 4 (for
#          block.diff type="B").
size.block <-  p/n.block
# true.rho: correlation within a block
# block.cor: correlation between blocks
# block.diff: "A": the true differences are in two blocks
#             "B": the true differences are in four blocks
if(! block.diff %in% c("A", "B")) stop("block.diff must be A or B (at the moment).")
# true.mu: a vector of mean level of CNA across genomic locations.
if(is.null(true.mu)) true.mu <- rep(c(rep(1, size.block), rep(1.5, size.block), rep(1, size.block), rep(0.5, size.block)), p/(size.block*4))
if(length(true.mu) != p) stop("The length of true.mu must be equal to p.")

# Covariance matrix of the simulated (noisy) data
 true.Sigma <- matrix(0,p,p)
 temp <- matrix(true.rho, size.block, size.block)
 for(k in 1:n.block){
 true.Sigma[((k-1)*size.block+1):(k*size.block), ((k-1)*size.block+1):(k*size.block)] <- temp
  }# end over number of block
 temp <- matrix(block.cor, size.block, size.block)
 for(k in 1:(n.block-1)){
 true.Sigma[(k*size.block+1):((k+1)*size.block), ((k-1)*size.block+1):(k*size.block)] <- temp
 true.Sigma[((k-1)*size.block+1):(k*size.block), (k*size.block+1):((k+1)*size.block)] <- temp
  }# end over number of block
 diag(true.Sigma) <- 1

# true differences
if(block.diff=="B"){
true.d1 <- c(rep(effect.diff,size.block), rep(-effect.diff, size.block),
             rep(-effect.diff,size.block), rep(effect.diff, size.block), rep(0,p-4*size.block))
       } else {
        true.d1 <- c(rep(effect.diff,size.block), rep(-effect.diff, size.block), rep(0,p-2*size.block))
       }# end if block.diff

sim.dat <- list()
for(j in 1:n.sim){
cat("Simulated data",j,"\n")
Z.sim <- mvrnorm(n.obs, mu=true.mu, Sigma=true.Sigma)
Z.sim[1:(n.obs/2),] = t(t(Z.sim[1:(n.obs/2),])+true.d1)
sample.CBS = seg(Z.sim, denoise = "CBS")
sim.dat <- c(sim.dat, list(sample.CBS))
}# end of iteration over j

return(sim.dat)
}
