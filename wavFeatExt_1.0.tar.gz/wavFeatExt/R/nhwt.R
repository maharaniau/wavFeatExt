nhwt <-
function(data, type="detail"){
  n = ncol(data)
  n.sampl = nrow(data)
  if(is.null(n.sampl) == T){
    data=t(as.matrix(data))
    n = ncol(data)
    n.sampl = nrow(data)
  }
  
  n.up = ceiling(log2(n))
  n.extend = 2^n.up
  n.res = n.extend-n
  
  if(n.res==0){
    data.extend = data
  }else{
    data.extend = matrix(0,n.sampl,n.extend)
    for(i in 1:n.sampl){
      if(is.even(n.res)==TRUE){
        data.extend[i,] = padarray(data[i,], c(0,n.res/2), 1, "both")
      }else{
        temp=vector()
        temp = padarray(data[i,], c(0,floor(n.res/2)), 1, "both")
        data.extend[i,] = c(temp, data[i,ceiling(n.res/2)])
      }
    }
  }
  
  
  coef.ndwt = data.ndwt = vector("list", n.up-1)
  for (i in 1:(n.up-1)) {
    coef.ndwt[[i]] = matrix(NA, nrow=n.sampl, ncol=n.extend)
    data.ndwt[[i]] = matrix(NA, nrow=n.sampl, ncol=n)
  }
  
  scale=1
  for(k in (n.up-1):1){
    for(i in 1:n.sampl){
      if(type=="detail"){coef.ndwt[[scale]][i,] = temp = accessD(wd(data.extend[i,], filter.number=1, family="DaubExPhase",type="station"), level=k)}
      if(type=="scaling"){coef.ndwt[[scale]][i,] = temp = accessC(wd(data.extend[i,], filter.number=1, family="DaubExPhase",type="station"), level=k)}
      
      if(n.res==0){
        coef.ndwt[[scale]][i,(1+(2^(scale-1)-1)):n] = temp[1:(n-(2^(scale-1)-1))]
        coef.ndwt[[scale]][i,1:(2^(scale-1))] = temp[(n-(2^(scale-1)-1)):n]
        data.ndwt[[scale]][i,] = coef.ndwt[[scale]][i,]
      }else{
        coef.ndwt[[scale]][i,(1+(2^(scale-1)-1)):n.extend] = temp[1:(n.extend-(2^(scale-1)-1))]
        coef.ndwt[[scale]][i,1:(2^(scale-1))] = temp[(n.extend-(2^(scale-1)-1)):n.extend]
        data.ndwt[[scale]][i,] = coef.ndwt[[scale]][i,ceiling(n.res/2):(ceiling(n.res/2)+n-1)]
      }
      
    }
    scale=scale+1
  }
  
  
  return(data.ndwt)
}
