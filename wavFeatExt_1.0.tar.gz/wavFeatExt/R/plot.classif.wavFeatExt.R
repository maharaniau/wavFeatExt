plot.classif.wavFeatExt <-
function(data, type, adjust=T,...){
  # This function plot the output from the function 
  # classif.wavFeatExt (AUC or classification error)
  # Input:
  # data: output of function classif.wavFeatExt
  # type: type of the output of classif.wavFeatExt you want to plot
  
  scale = 1:((ncol(data$AUC)-1)/2)
  names = paste("d", scale)
  
  if(type=="AUC"){
    boxplot(data$AUC, names=c(paste("d", scale, sep=""), paste("s", scale, sep=""), "seg"), main=paste("AUC:", data$method), ...)
    abline(h=c(median(data$AUC[,ncol(data$AUC)]), max(colMedians(data$AUC))), lty=c(2,3), col=c("red", "blue"))
  }
  if(type=="CE"){
    boxplot(data$CE, names=c(paste("d", scale, sep=""), paste("s", scale, sep=""), "seg"), main=paste("Classification Error:", data$method), ...)
    abline(h=c(median(data$CE[,ncol(data$CE)]), min(colMedians(data$CE))), lty=c(2,3), col=c("red", "blue"))
  }
}
